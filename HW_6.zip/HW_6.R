# ~ Homework 6 ~

## Question 1
# Load the dataset
people <- read.csv("C:\\Users\\icwin\\OneDrive - Indiana University\\[I-421] Data Mining\\peoplesize.csv")
# Install and load necessary packages
install.packages("rpart.plot")
library(rpart.plot)
install.packages("party")
library(party)
# Split dataset into training dataset and test dataset
set.seed(1234)
ind <- sample(2, nrow(people), replace = TRUE, prob = c(0.7, 0.3))
trainData <- people[ind==1,]
testData <- people[ind==2,]
# Create tree with root node "gender"
gender_tree <- rpart(class ~ . - name,data = trainData, method = "class", parms = list(split= "gini"), control = rpart.control(cp = 0))
rpart.plot(gender_tree)
# Create tree with root node "shirt size"
shirt_plot <- rpart(class ~ . - name, data = trainData, method = "class", parms = list)
rpart.plot(shirt_plot)

## Question 2
# Located in the word document

## Question 3
# Load in the IRIS dataset
data(iris)
# Define the formula for the decision tree
formula <- Species ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width
# Split the dataset into training and testing sets
# for reproducibility
set.seed(123) 
train_indices <- sample(1:nrow(iris), 0.7 * nrow(iris))
train_data <- iris[train_indices, ]
test_data <- iris[-train_indices, ]
# Train the decision tree model
model <- rpart(formula, data = train_data, method = "class")
# Predict the labels for the testing dataset
predicted_labels <- predict(model, test_data, type = "class")
# Print the predicted labels
print(predicted_labels)
# Plot the decision tree
# Set margins
par(mar = c(1,1,1,1))
plot(model)
text(model, pretty = 0)